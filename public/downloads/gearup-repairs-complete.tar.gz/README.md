# GearUp Repairs

**Your Complete Fitness Equipment Service Marketplace Platform**

A full-stack platform connecting consumers with fitness equipment technicians and parts suppliers, with AI-powered features and automated commission tracking.

---

## 🎯 What This Platform Does

**For Consumers:**
- Manage fitness equipment inventory
- Find and book verified technicians
- AI-powered maintenance recommendations
- Buy equipment parts from marketplace
- Rate and review services

**For Technicians:**
- Receive service requests
- Manage bookings and schedule
- Request payments after service
- Build reputation through reviews
- Earn 85% of service fees (15% platform commission)

**For You (Platform Owner):**
- Earn 15% commission on all service bookings
- Earn 10% commission on all parts sales
- Monitor revenue in real-time
- Manage users, bookings, and reviews
- Full analytics dashboard

---

## 💰 Revenue Model

**Automated Commission System:**
- Service bookings: **15% platform commission**
- Parts sales: **10% platform commission**
- All commissions tracked automatically
- Zero manual calculation required

**Example Monthly Revenue:**
- 100 service bookings @ $100 avg = **$1,500** commission
- 50 parts sales @ $150 avg = **$750** commission
- **Total: $2,250/month** passive income

*Scale as you grow!*

---

## 🛠️ Tech Stack

**Backend:**
- FastAPI (Python)
- MongoDB (Database)
- OpenAI GPT-5 (AI features)
- Stripe (Payments)
- Emergent OAuth (Authentication)

**Frontend:**
- React 19
- Shadcn UI Components
- TailwindCSS
- Axios

---

## ✨ Features

✅ **Three Complete Portals**
- Consumer Dashboard
- Technician Dashboard  
- Admin Dashboard (revenue tracking)

✅ **AI-Powered Features**
- Smart technician matching
- Predictive maintenance
- Parts recommendations
- Price estimation

✅ **Payment System**
- Stripe integration
- Automatic commission splits
- Transaction tracking

✅ **User Management**
- Google OAuth login
- Role-based access
- Profile management

✅ **Service Booking**
- Search technicians by location
- View ratings and reviews
- Schedule appointments
- Payment processing

✅ **Parts Marketplace**
- Browse parts catalog
- Filter by compatibility
- AI part recommendations
- Secure checkout

---

## 📦 Quick Start

See `DEPLOYMENT_GUIDE.md` for complete setup instructions.

**Local Development:**
```bash
# Backend
cd backend
pip install -r requirements.txt
cp .env.example .env
uvicorn server:app --reload

# Frontend
cd frontend
yarn install
cp .env.example .env
yarn start
```

---

## 👥 User Roles

**Consumer** - Equipment owners who need service
**Technician** - Service providers (independent contractors)
**Admin** - You (platform owner)

**Admin Login:**
1. Sign in with Google
2. Update your user role to 'admin' in MongoDB
3. Access admin dashboard at `/admin/dashboard`

---

## 🔐 Security

- HTTPS enforced in production
- Secure authentication via Google OAuth
- Session-based access control
- Payment data handled by Stripe (PCI compliant)
- Environment variable configuration
- CORS protection

---

## 📊 Database Collections

- `users` - All user accounts (consumers, technicians, admins)
- `bookings` - Service requests and appointments
- `parts` - Equipment parts catalog
- `reviews` - Ratings and feedback
- `payment_transactions` - All payments with commission tracking
- `sessions` - User authentication sessions

---

## 🚀 Deployment

Ready for production deployment on:
- Traditional VPS (DigitalOcean, AWS EC2, Linode)
- Docker containers
- PaaS platforms (Heroku, Railway, Render)

See `DEPLOYMENT_GUIDE.md` for detailed instructions.

---

## 📈 Business Model

**Independent Contractor Model:**
- Technicians are self-employed contractors
- They handle their own liability insurance
- Platform just connects and facilitates payments
- Similar to Uber, Airbnb, TaskRabbit

**Scalable Revenue:**
- More users = More revenue
- Automated commission system
- Low overhead costs
- Passive income potential

---

## 🎨 Design

- Modern ocean blue color scheme
- Manrope & Inter fonts
- Glass-morphism effects
- Fully responsive (mobile-first)
- Professional and trustworthy appearance

---

## 📞 Support & Maintenance

**Monitoring:**
- Health check endpoint: `/api/health`
- Transaction monitoring in admin dashboard
- PM2 process management

**Backups:**
- Regular MongoDB backups
- Store in separate location
- Test restore procedure

---

## 📄 License

This code is yours to use commercially. Build your business!

---

## 🎉 What You Get

✅ Complete working platform
✅ Three user portals
✅ Automated revenue system
✅ AI-powered features
✅ Payment processing
✅ Admin dashboard
✅ Modern, responsive design
✅ Production-ready code
✅ Deployment guide
✅ Full documentation

**Start your fitness equipment service marketplace today!** 🚀