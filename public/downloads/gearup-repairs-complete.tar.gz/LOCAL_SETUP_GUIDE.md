# GearUp Repairs - LOCAL SETUP GUIDE
## Test on Your Personal Computer (Windows/Mac/Linux)

---

## 📥 STEP 1: DOWNLOAD THE CODE

**Download Link:**
https://fitfix-connect.preview.emergentagent.com/downloads/gearup-repairs-complete.tar.gz

**Alternative Download Page:**
https://fitfix-connect.preview.emergentagent.com/download.html

---

## 💻 STEP 2: INSTALL REQUIRED SOFTWARE

### For Windows:

**1. Install Python 3.11:**
- Download from: https://www.python.org/downloads/
- ✅ Check "Add Python to PATH" during installation
- Verify: Open Command Prompt, type `python --version`

**2. Install Node.js 18+:**
- Download from: https://nodejs.org/
- Choose LTS version
- Verify: Open Command Prompt, type `node --version`

**3. Install MongoDB:**
- Download from: https://www.mongodb.com/try/download/community
- Install as Windows Service
- Or use MongoDB Atlas (free cloud): https://www.mongodb.com/cloud/atlas

**4. Install Yarn:**
```cmd
npm install -g yarn
```

---

### For Mac:

**1. Install Homebrew (if not installed):**
```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

**2. Install Python, Node, MongoDB:**
```bash
brew install python@3.11 node mongodb-community yarn
```

**3. Start MongoDB:**
```bash
brew services start mongodb-community
```

---

### For Linux (Ubuntu/Debian):

```bash
# Update system
sudo apt update

# Install Python
sudo apt install python3.11 python3-pip

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install nodejs

# Install Yarn
npm install -g yarn

# Install MongoDB
wget -qO - https://www.mongodb.org/static/pgp/server-6.0.asc | sudo apt-key add -
echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu focal/mongodb-org/6.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-6.0.list
sudo apt update
sudo apt install -y mongodb-org

# Start MongoDB
sudo systemctl start mongod
sudo systemctl enable mongod
```

---

## 📂 STEP 3: EXTRACT AND SETUP

**1. Extract the downloaded file:**

**Windows:**
- Use 7-Zip or WinRAR to extract
- Or use Command Prompt:
```cmd
tar -xzf gearup-repairs-complete.tar.gz
cd gearup-repairs-complete
```

**Mac/Linux:**
```bash
tar -xzf gearup-repairs-complete.tar.gz
cd gearup-repairs-complete
```

**2. You should see:**
```
gearup-repairs-complete/
├── backend/
├── frontend/
├── seed_data.py
├── README.md
└── DEPLOYMENT_GUIDE.md
```

---

## 🔧 STEP 4: CONFIGURE ENVIRONMENT VARIABLES

### Backend Configuration:

**1. Create backend/.env file:**

**Windows:**
```cmd
cd backend
copy .env.example .env
notepad .env
```

**Mac/Linux:**
```bash
cd backend
cp .env.example .env
nano .env
```

**2. Edit backend/.env:**
```env
MONGO_URL="mongodb://localhost:27017"
DB_NAME="gearup_repairs"
CORS_ORIGINS="*"
EMERGENT_LLM_KEY=sk-emergent-40bDfCbD813458f997
STRIPE_API_KEY=sk_test_emergent
AUTH_API_URL=https://demobackend.emergentagent.com/auth/v1/env/oauth/session-data
PLATFORM_BOOKING_COMMISSION=0.15
PLATFORM_PARTS_COMMISSION=0.10
```

**✅ These are the correct test credentials - no changes needed!**

---

### Frontend Configuration:

**1. Create frontend/.env file:**

**Windows:**
```cmd
cd ..\frontend
copy .env.example .env
notepad .env
```

**Mac/Linux:**
```bash
cd ../frontend
cp .env.example .env
nano .env
```

**2. Edit frontend/.env:**
```env
REACT_APP_BACKEND_URL=http://localhost:8001
REACT_APP_AUTH_URL=https://auth.emergentagent.com
```

**✅ This points to your local backend!**

---

## 🚀 STEP 5: INSTALL DEPENDENCIES

### Backend:

**Windows Command Prompt / Mac/Linux Terminal:**
```bash
cd backend
pip install -r requirements.txt
```

**If you get errors, try:**
```bash
pip3 install -r requirements.txt
```

**⏱️ Takes 2-3 minutes**

---

### Frontend:

**Windows Command Prompt / Mac/Linux Terminal:**
```bash
cd ../frontend
yarn install
```

**⏱️ Takes 3-5 minutes**

---

## 🗄️ STEP 6: SEED THE DATABASE

**Run from the main folder:**

**Windows:**
```cmd
cd ..
python seed_data.py
```

**Mac/Linux:**
```bash
cd ..
python3 seed_data.py
```

**You should see:**
```
🌱 Seeding GearUp Repairs database...
✅ Inserted 3 technicians
✅ Inserted 1 consumers
✅ Inserted 1 admin user
✅ Inserted 5 parts
✅ Inserted 2 bookings
✅ Inserted 1 reviews
🎉 Database seeding completed successfully!
```

**Admin Login:** admin@gearuprepairs.com (after Google OAuth)

---

## ▶️ STEP 7: RUN THE APPLICATION

### Terminal 1 - Backend:

**Windows:**
```cmd
cd backend
python -m uvicorn server:app --reload --host 0.0.0.0 --port 8001
```

**Mac/Linux:**
```bash
cd backend
python3 -m uvicorn server:app --reload --host 0.0.0.0 --port 8001
```

**✅ You should see:**
```
INFO:     Uvicorn running on http://0.0.0.0:8001
INFO:     Application startup complete.
```

**⚠️ Keep this terminal open!**

---

### Terminal 2 - Frontend:

**Open a NEW terminal/command prompt:**

**Windows/Mac/Linux:**
```bash
cd frontend
yarn start
```

**✅ Browser should automatically open to:**
```
http://localhost:3000
```

**⚠️ Keep this terminal open too!**

---

## 🎉 STEP 8: TEST THE APPLICATION

**1. Open Browser:**
```
http://localhost:3000
```

**2. You should see:**
- GearUp Repairs landing page
- "Get Started with Google" button

**3. Test Features:**
- ✅ Click "Get Started" - should redirect to Google login
- ✅ After login, you'll see consumer dashboard
- ✅ Try adding equipment
- ✅ Browse technicians
- ✅ Check marketplace

**4. Test Admin Portal:**
- Login with an account
- Open MongoDB Compass or mongosh
- Update your user role to "admin"
- Refresh page - you'll see admin dashboard

---

## 🛠️ TROUBLESHOOTING

### Backend won't start:

**Check MongoDB is running:**
```bash
# Windows
services.msc (look for MongoDB)

# Mac
brew services list

# Linux
sudo systemctl status mongod
```

**If not running, start it:**
```bash
# Mac
brew services start mongodb-community

# Linux
sudo systemctl start mongod

# Windows
Start from Services panel
```

---

### Frontend won't start:

**Clear cache and reinstall:**
```bash
cd frontend
rm -rf node_modules package-lock.json
yarn install
yarn start
```

---

### Can't connect to backend:

**1. Check backend is running on port 8001**
**2. Check frontend .env has:** `REACT_APP_BACKEND_URL=http://localhost:8001`
**3. Restart both servers**

---

### Authentication not working:

**This is normal for localhost!**
- Emergent OAuth is configured for the production domain
- For local testing, you can:
  - Test other features without login
  - Or temporarily deploy to test auth

---

## 💰 CHEAPEST DEPLOYMENT OPTIONS (For Market Testing)

### Option 1: Railway.app (RECOMMENDED - FREE)
**Cost:** $0/month (free tier)
**Setup:** 5 minutes

**Steps:**
1. Push code to GitHub
2. Go to https://railway.app
3. Connect GitHub repo
4. Add MongoDB plugin (free)
5. Deploy! ✅

**Limits:**
- $5 free credit/month
- Good for 100-500 users/month
- Perfect for testing market

---

### Option 2: Render.com (FREE)
**Cost:** $0/month (free tier)
**Setup:** 10 minutes

**What's free:**
- Web service (backend)
- Static site (frontend)
- PostgreSQL database

**You need:**
- MongoDB Atlas (free tier) - 512MB

**Total Cost:** $0/month

---

### Option 3: Vercel + Railway (FREE)
**Cost:** $0/month

**Split hosting:**
- Frontend: Vercel (free, unlimited)
- Backend + DB: Railway (free $5 credit)

**Best performance for free tier!**

---

### Option 4: DigitalOcean Droplet (CHEAPEST PAID)
**Cost:** $4/month (student) or $6/month (regular)

**What you get:**
- Full VPS
- 1GB RAM
- 25GB SSD
- Run everything on one server

**Setup:** 30 minutes
**Best for:** Serious testing, want full control

---

## 📊 RECOMMENDED PATH:

**For Testing Market (0-1000 users):**
```
1. Test locally (FREE) ✅ You're here
2. Deploy to Railway.app (FREE)
3. Share with 10-20 beta users
4. Collect feedback
5. If positive, upgrade to paid hosting
```

**Cost Breakdown:**
- Month 1-3: $0 (Railway free tier)
- Month 4+: $6-12/month (basic VPS or Railway hobby plan)

---

## 🎯 READY TO DEPLOY?

**After testing locally, follow these steps:**

1. **Create GitHub account** (if you don't have)
2. **Push your code to GitHub:**
```bash
cd gearup-repairs-complete
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/yourusername/gearup-repairs.git
git push -u origin main
```

3. **Choose deployment platform** (Railway recommended)
4. **Follow their deployment guide**
5. **Update .env with production URLs**
6. **Test with real users!**

---

## ✅ CHECKLIST

**Local Testing:**
- [ ] All software installed
- [ ] Code extracted
- [ ] .env files configured
- [ ] Dependencies installed
- [ ] Database seeded
- [ ] Backend running on port 8001
- [ ] Frontend running on port 3000
- [ ] Can access http://localhost:3000
- [ ] Features work (except auth on localhost)

**Ready for Deployment:**
- [ ] Tested locally
- [ ] Code on GitHub
- [ ] Chosen hosting platform
- [ ] MongoDB Atlas account ready (if needed)
- [ ] Stripe account created
- [ ] Ready to deploy!

---

## 🆘 NEED HELP?

**Common Issues:**
1. **Port already in use:** Close other apps on ports 8001/3000
2. **MongoDB connection failed:** Start MongoDB service
3. **Module not found:** Run pip/yarn install again
4. **CORS errors:** Check backend CORS_ORIGINS setting

---

## 🎉 YOU'RE READY!

Download the code, follow this guide, and you'll have GearUp Repairs running on your computer in 30 minutes!

**Next:** Test locally → Deploy to Railway (free) → Share with beta users → Grow! 🚀
