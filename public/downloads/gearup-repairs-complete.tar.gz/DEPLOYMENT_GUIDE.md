# GearUp Repairs - Deployment Guide

## 📦 Package Contents

```
gearup-repairs/
├── backend/                 # FastAPI backend
│   ├── server.py           # Main API server
│   ├── requirements.txt    # Python dependencies
│   └── .env.example        # Environment variables template
├── frontend/               # React frontend
│   ├── src/               # Source code
│   ├── package.json       # Node dependencies
│   └── .env.example       # Environment variables template
├── seed_data.py           # Database seeding script
└── README.md              # Project documentation
```

---

## 🚀 Quick Start (Local Development)

### Prerequisites
- Python 3.11+
- Node.js 18+
- MongoDB
- Yarn package manager

### Backend Setup

1. **Install dependencies:**
```bash
cd backend
pip install -r requirements.txt
```

2. **Create .env file:**
```bash
# backend/.env
MONGO_URL="mongodb://localhost:27017"
DB_NAME="gearup_repairs"
CORS_ORIGINS="*"
EMERGENT_LLM_KEY=sk-emergent-40bDfCbD813458f997
STRIPE_API_KEY=sk_test_emergent
AUTH_API_URL=https://demobackend.emergentagent.com/auth/v1/env/oauth/session-data
PLATFORM_BOOKING_COMMISSION=0.15
PLATFORM_PARTS_COMMISSION=0.10
```

3. **Run backend:**
```bash
uvicorn server:app --host 0.0.0.0 --port 8001 --reload
```

### Frontend Setup

1. **Install dependencies:**
```bash
cd frontend
yarn install
```

2. **Create .env file:**
```bash
# frontend/.env
REACT_APP_BACKEND_URL=http://localhost:8001
REACT_APP_AUTH_URL=https://auth.emergentagent.com
```

3. **Run frontend:**
```bash
yarn start
```

### Database Setup

1. **Start MongoDB:**
```bash
mongod --dbpath /path/to/data
```

2. **Seed database:**
```bash
python3 seed_data.py
```

---

## 🌐 Production Deployment

### Option 1: Traditional VPS (DigitalOcean, AWS EC2, etc.)

**Server Requirements:**
- 2GB RAM minimum
- Ubuntu 20.04+ / Debian 11+
- MongoDB installed
- Nginx for reverse proxy
- SSL certificate (Let's Encrypt)

**Steps:**

1. **Install dependencies:**
```bash
sudo apt update
sudo apt install python3-pip nodejs npm mongodb nginx certbot
npm install -g yarn pm2
```

2. **Clone your code:**
```bash
git clone <your-repo>
cd gearup-repairs
```

3. **Backend setup:**
```bash
cd backend
pip3 install -r requirements.txt

# Create .env with production values
nano .env

# Run with PM2
pm2 start "uvicorn server:app --host 0.0.0.0 --port 8001" --name gearup-backend
pm2 save
pm2 startup
```

4. **Frontend setup:**
```bash
cd frontend

# Update .env with production backend URL
nano .env

# Build for production
yarn build

# Serve with PM2
pm2 serve build 3000 --spa --name gearup-frontend
pm2 save
```

5. **Nginx configuration:**
```nginx
server {
    listen 80;
    server_name yourdomain.com;

    location /api {
        proxy_pass http://localhost:8001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

6. **SSL Certificate:**
```bash
sudo certbot --nginx -d yourdomain.com
```

### Option 2: Docker Deployment

**Create docker-compose.yml:**
```yaml
version: '3.8'

services:
  mongodb:
    image: mongo:6
    volumes:
      - mongodb_data:/data/db
    environment:
      - MONGO_INITDB_DATABASE=gearup_repairs

  backend:
    build: ./backend
    ports:
      - "8001:8001"
    environment:
      - MONGO_URL=mongodb://mongodb:27017
      - DB_NAME=gearup_repairs
    depends_on:
      - mongodb

  frontend:
    build: ./frontend
    ports:
      - "3000:3000"
    environment:
      - REACT_APP_BACKEND_URL=http://yourdomain.com:8001
    depends_on:
      - backend

volumes:
  mongodb_data:
```

**Deploy:**
```bash
docker-compose up -d
```

### Option 3: Platform as a Service (Heroku, Railway, Render)

**For Backend (Heroku example):**
```bash
heroku create gearup-repairs-api
heroku addons:create mongolab:sandbox
git push heroku main
```

**For Frontend (Vercel/Netlify):**
1. Connect GitHub repo
2. Set build command: `yarn build`
3. Set publish directory: `build`
4. Add environment variable: `REACT_APP_BACKEND_URL`

---

## 🔐 Production Configuration

### Environment Variables

**Backend (.env):**
```env
MONGO_URL=mongodb://production-host:27017
DB_NAME=gearup_repairs
CORS_ORIGINS=https://yourdomain.com
EMERGENT_LLM_KEY=<your-emergent-key>
STRIPE_API_KEY=<your-production-stripe-key>
AUTH_API_URL=https://demobackend.emergentagent.com/auth/v1/env/oauth/session-data
PLATFORM_BOOKING_COMMISSION=0.15
PLATFORM_PARTS_COMMISSION=0.10
```

**Frontend (.env):**
```env
REACT_APP_BACKEND_URL=https://api.yourdomain.com
REACT_APP_AUTH_URL=https://auth.emergentagent.com
```

### Get Production Stripe Keys

1. Go to https://dashboard.stripe.com
2. Create account / Sign in
3. Get API keys from Developers > API keys
4. Use **Live** keys (starts with `sk_live_...`)

### Configure Emergent Auth

Update redirect URLs in Emergent OAuth settings to your production domain.

---

## 💰 Commission Configuration

You can adjust commission rates in `backend/.env`:

```env
PLATFORM_BOOKING_COMMISSION=0.15  # 15% on service bookings
PLATFORM_PARTS_COMMISSION=0.10    # 10% on parts sales
```

Changes take effect on restart.

---

## 📊 Admin Access

**Default Admin User:**
- Email: admin@gearuprepairs.com
- Create via Google OAuth first time
- Then run: Update user role to 'admin' in MongoDB

**MongoDB Update:**
```javascript
db.users.updateOne(
  { email: "your-email@example.com" },
  { $set: { role: "admin" } }
)
```

---

## 🗄️ Database Backup

**Backup:**
```bash
mongodump --db gearup_repairs --out /backup/$(date +%Y%m%d)
```

**Restore:**
```bash
mongorestore --db gearup_repairs /backup/20250119/gearup_repairs
```

**Automate backups (cron):**
```bash
0 2 * * * mongodump --db gearup_repairs --out /backup/$(date +\%Y\%m\%d)
```

---

## 📧 Email Notifications (TODO)

Add email service (SendGrid, AWS SES) for:
- Booking confirmations
- Payment notifications
- Service completion
- Review requests

---

## 🔍 Monitoring

**Backend Health Check:**
```bash
curl https://api.yourdomain.com/api/health
```

**Monitor with PM2:**
```bash
pm2 monit
```

**Logs:**
```bash
pm2 logs gearup-backend
pm2 logs gearup-frontend
```

---

## 🐛 Troubleshooting

**Backend not starting:**
- Check MongoDB is running: `sudo systemctl status mongod`
- Check logs: `pm2 logs gearup-backend`
- Verify .env variables are set

**Frontend not connecting:**
- Check REACT_APP_BACKEND_URL is correct
- Check CORS_ORIGINS includes your frontend URL
- Check network/firewall rules

**Payments not working:**
- Verify Stripe API key is production key
- Check Stripe webhook is configured
- Test with Stripe test cards first

**OAuth not working:**
- Verify redirect URL matches production domain
- Check AUTH_API_URL is accessible

---

## 📈 Scaling

**When to scale:**
- 1000+ users: Add Redis for caching
- 10,000+ users: Separate database server
- 100,000+ users: Load balancer + multiple app servers

**Performance tips:**
- Use CDN for frontend assets
- Enable MongoDB indexes
- Implement Redis caching
- Use database read replicas

---

## 🔒 Security Checklist

- [ ] Use HTTPS in production
- [ ] Set strong MongoDB password
- [ ] Enable MongoDB authentication
- [ ] Use production Stripe keys
- [ ] Set secure CORS origins
- [ ] Regular security updates
- [ ] Enable rate limiting
- [ ] Backup database regularly
- [ ] Monitor error logs
- [ ] Use environment variables (never hardcode)

---

## 📞 Support

For issues or questions:
1. Check logs first
2. Review this guide
3. Check MongoDB connectivity
4. Verify all environment variables
5. Test API endpoints with curl

---

## 📄 License

This code is yours to use, modify, and deploy commercially. Build your business! 🚀
