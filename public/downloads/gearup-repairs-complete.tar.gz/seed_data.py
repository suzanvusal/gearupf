#!/usr/bin/env python3

import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
import uuid
from datetime import datetime, timezone

async def seed_database():
    """Seed the database with sample data for testing"""
    
    # Connect to MongoDB
    client = AsyncIOMotorClient("mongodb://localhost:27017")
    db = client["gearup_repairs"]
    
    print("🌱 Seeding GearUp Repairs database...")
    
    # Clear existing data
    await db.users.delete_many({})
    await db.parts.delete_many({})
    await db.bookings.delete_many({})
    await db.reviews.delete_many({})
    
    # Sample technicians
    technicians = [
        {
            "id": str(uuid.uuid4()),
            "email": "john.tech@example.com",
            "name": "John Smith",
            "picture": "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150",
            "role": "technician",
            "location": "New York, NY",
            "phone": "+1-555-0101",
            "services_offered": ["repair", "installation", "maintenance"],
            "qualifications": "Certified fitness equipment technician with 8+ years experience",
            "certifications": ["ACSM Certified", "NCHEC Certified"],
            "availability": "Mon-Fri 9AM-6PM",
            "hourly_rate": 85.0,
            "rating": 4.8,
            "total_reviews": 127,
            "created_at": datetime.now(timezone.utc).isoformat()
        },
        {
            "id": str(uuid.uuid4()),
            "email": "sarah.tech@example.com",
            "name": "Sarah Johnson",
            "picture": "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150",
            "role": "technician",
            "location": "Los Angeles, CA",
            "phone": "+1-555-0102",
            "services_offered": ["repair", "inspection", "maintenance"],
            "qualifications": "Specialized in treadmill and elliptical repairs",
            "certifications": ["IHRSA Certified", "Manufacturer Certified"],
            "availability": "Mon-Sat 8AM-7PM",
            "hourly_rate": 75.0,
            "rating": 4.9,
            "total_reviews": 89,
            "created_at": datetime.now(timezone.utc).isoformat()
        },
        {
            "id": str(uuid.uuid4()),
            "email": "mike.tech@example.com",
            "name": "Mike Rodriguez",
            "picture": "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150",
            "role": "technician",
            "location": "Chicago, IL",
            "phone": "+1-555-0103",
            "services_offered": ["repair", "installation", "inspection"],
            "qualifications": "Expert in commercial gym equipment",
            "certifications": ["NASM Certified", "Equipment Safety Certified"],
            "availability": "Tue-Sun 10AM-8PM",
            "hourly_rate": 90.0,
            "rating": 4.7,
            "total_reviews": 156,
            "created_at": datetime.now(timezone.utc).isoformat()
        }
    ]
    
    # Sample consumers
    consumers = [
        {
            "id": str(uuid.uuid4()),
            "email": "consumer1@example.com",
            "name": "Alice Wilson",
            "picture": "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150",
            "role": "consumer",
            "location": "New York, NY",
            "phone": "+1-555-0201",
            "equipment": [
                {
                    "name": "Treadmill",
                    "brand": "NordicTrack",
                    "model": "Commercial 1750",
                    "condition": "good",
                    "purchase_date": "2022-03-15"
                },
                {
                    "name": "Elliptical",
                    "brand": "ProForm",
                    "model": "Pro 16.9",
                    "condition": "fair",
                    "purchase_date": "2021-08-20"
                }
            ],
            "created_at": datetime.now(timezone.utc).isoformat()
        }
    ]
    
    # Admin user
    admin = {
        "id": str(uuid.uuid4()),
        "email": "admin@gearuprepairs.com",
        "name": "Admin User",
        "picture": None,
        "role": "admin",
        "location": "Platform",
        "phone": "+1-555-9999",
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    
    # Sample parts
    parts = [
        {
            "id": str(uuid.uuid4()),
            "name": "Treadmill Walking Belt",
            "category": "belt",
            "brand": "NordicTrack",
            "compatible_models": ["Commercial 1750", "Commercial 2950", "X11i"],
            "description": "Premium walking belt for NordicTrack commercial series treadmills",
            "price": 149.99,
            "supplier_id": str(uuid.uuid4()),
            "supplier_name": "FitParts Direct",
            "stock_quantity": 25,
            "image_url": "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=300",
            "rating": 4.6,
            "total_reviews": 34,
            "created_at": datetime.now(timezone.utc).isoformat()
        },
        {
            "id": str(uuid.uuid4()),
            "name": "Elliptical Drive Belt",
            "category": "belt",
            "brand": "ProForm",
            "compatible_models": ["Pro 16.9", "Pro 12.9", "Endurance 920"],
            "description": "Durable drive belt for ProForm elliptical machines",
            "price": 89.99,
            "supplier_id": str(uuid.uuid4()),
            "supplier_name": "Gym Parts Plus",
            "stock_quantity": 18,
            "image_url": "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=300",
            "rating": 4.4,
            "total_reviews": 22,
            "created_at": datetime.now(timezone.utc).isoformat()
        },
        {
            "id": str(uuid.uuid4()),
            "name": "Treadmill Motor",
            "category": "motor",
            "brand": "Universal",
            "compatible_models": ["Various Models"],
            "description": "2.5 HP continuous duty treadmill motor",
            "price": 299.99,
            "supplier_id": str(uuid.uuid4()),
            "supplier_name": "Motor Specialists",
            "stock_quantity": 8,
            "image_url": "https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=300",
            "rating": 4.8,
            "total_reviews": 67,
            "created_at": datetime.now(timezone.utc).isoformat()
        },
        {
            "id": str(uuid.uuid4()),
            "name": "Console Display Screen",
            "category": "electronics",
            "brand": "NordicTrack",
            "compatible_models": ["Commercial 1750", "Commercial 2950"],
            "description": "10-inch touchscreen display for NordicTrack treadmills",
            "price": 399.99,
            "supplier_id": str(uuid.uuid4()),
            "supplier_name": "Tech Fitness Parts",
            "stock_quantity": 12,
            "image_url": "https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=300",
            "rating": 4.5,
            "total_reviews": 28,
            "created_at": datetime.now(timezone.utc).isoformat()
        },
        {
            "id": str(uuid.uuid4()),
            "name": "Resistance Cable Set",
            "category": "cable",
            "brand": "Universal",
            "compatible_models": ["Most Cable Machines"],
            "description": "Heavy-duty resistance cables for strength training equipment",
            "price": 45.99,
            "supplier_id": str(uuid.uuid4()),
            "supplier_name": "Cable Solutions",
            "stock_quantity": 35,
            "image_url": "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=300",
            "rating": 4.3,
            "total_reviews": 15,
            "created_at": datetime.now(timezone.utc).isoformat()
        }
    ]
    
    # Insert data
    await db.users.insert_many(technicians + consumers + [admin])
    await db.parts.insert_many(parts)
    
    print(f"✅ Inserted {len(technicians)} technicians")
    print(f"✅ Inserted {len(consumers)} consumers")
    print(f"✅ Inserted 1 admin user (admin@gearuprepairs.com)")
    print(f"✅ Inserted {len(parts)} parts")
    
    # Create some sample bookings
    tech_ids = [t["id"] for t in technicians]
    consumer_ids = [c["id"] for c in consumers]
    
    bookings = [
        {
            "id": str(uuid.uuid4()),
            "consumer_id": consumer_ids[0],
            "technician_id": tech_ids[0],
            "service_type": "repair",
            "equipment_details": {
                "name": "Treadmill",
                "issue_description": "Belt is slipping during use"
            },
            "preferred_date": "2025-01-25",
            "status": "pending",
            "estimated_cost": "75-125",
            "location": "New York, NY",
            "created_at": datetime.now(timezone.utc).isoformat()
        },
        {
            "id": str(uuid.uuid4()),
            "consumer_id": consumer_ids[0],
            "technician_id": tech_ids[1],
            "service_type": "maintenance",
            "equipment_details": {
                "name": "Elliptical",
                "issue_description": "Regular maintenance check"
            },
            "preferred_date": "2025-01-28",
            "status": "accepted",
            "estimated_cost": "50-75",
            "location": "New York, NY",
            "created_at": datetime.now(timezone.utc).isoformat()
        }
    ]
    
    await db.bookings.insert_many(bookings)
    print(f"✅ Inserted {len(bookings)} bookings")
    
    # Create some sample reviews
    reviews = [
        {
            "id": str(uuid.uuid4()),
            "reviewer_id": consumer_ids[0],
            "reviewer_name": "Alice Wilson",
            "target_type": "technician",
            "target_id": tech_ids[0],
            "rating": 5.0,
            "comment": "Excellent service! Fixed my treadmill quickly and professionally.",
            "booking_id": bookings[0]["id"],
            "created_at": datetime.now(timezone.utc).isoformat()
        }
    ]
    
    await db.reviews.insert_many(reviews)
    print(f"✅ Inserted {len(reviews)} reviews")
    
    print("\n🎉 Database seeding completed successfully!")
    
    client.close()

if __name__ == "__main__":
    asyncio.run(seed_database())